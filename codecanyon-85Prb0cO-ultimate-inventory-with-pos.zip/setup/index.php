<!DOCTYPE html>
<html>
<head>
	<title>Install/Update</title>
	<link rel="shortcut icon" href="../theme/images/favicon.ico">
	<link href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/cosmo/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-12">&nbsp;</div>
	</div>
	<div class="row">
		<div class="col-md-4">
			
		</div>
		<div class="col-md-4">

			<form class="border border-light p-5">
				<legend>Select Options to Continue</legend>



   <a href="install">
    <button class="btn btn-success btn-block my-4" type="button">Install</button>
   </a>
   &nbsp;
   <a href="update">
    <button class="btn btn-info btn-block my-4" type="button">Update</button>
   </a>

   
</form>
		</div>
	</div>
</div>

</body>
</html>